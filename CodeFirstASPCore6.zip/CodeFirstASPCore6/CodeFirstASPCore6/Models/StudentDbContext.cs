﻿using Microsoft.EntityFrameworkCore;

namespace CodeFirstASPCore6.Models
{
    public class StudentDbContext : DbContext
    {
        public StudentDbContext(DbContextOptions options) : base(options) //we use base to call constructor of base class
        {
                    
        }
         
        public DbSet<Student> Students { get; set; } // represent our table
    }
}
